/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.zapateria.zapateria;
import com.zapateria.zapateria.grafica.Menu;

/**
 *
 * @author estudiante
 */
public class Zapateria {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.setVisible(true);
    }
}
